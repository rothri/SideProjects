package com.jacks.pokerodds;

import com.jacks.pokerodds.R;

import android.app.Activity;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

public class customDialog extends DialogFragment {
	private String suit ="c";
	public OnSubmitListener mListener;
	Context context;
	int orgin;

	public customDialog (Context context,int v) {
		this.context = context;
		this.orgin   = v;
	}
	public void uncheckSuit(Dialog dialog,View suitButton){
		TableRow row = (TableRow) dialog.findViewById(R.id.tableRowC);
		int i=1;
		while (i<8){
			RadioButton rb = (RadioButton) row.getChildAt(i);
			if (rb.getId() != suitButton.getId()){
				rb.setChecked(false);
			}
			i+=2;
		}
	}
	public void changeColor(Dialog dialog, View suitButton){
		//also changes value of suit
		String color;
		if(R.id.diamond == suitButton.getId() || R.id.heart ==suitButton.getId()){
			color ="r";
			if (R.id.diamond == suitButton.getId()){
				suit="d";
			}
			else{
				suit="h";
			}
		}
		else{
			if(R.id.club ==suitButton.getId()){
				suit="c";
			}
			else{
				suit="s";
			}
			color="b";
		}
		TableLayout tl = (TableLayout) dialog.findViewById(R.id.tl);
		TableRow row = (TableRow) tl.getChildAt(1);
		ImageView v = (ImageView) row.getChildAt(0);
		if( v.getTag().toString()   ==  color+1){
			return;
		}
		int i =1;
		int k=0;
		int j=0;
		int id =0;
		String [] values={"1","5","9",
				"2","6","10",
				"3","7","j",
				"4","8","q",
		"k"};
		while (i<6){
			row = (TableRow) tl.getChildAt(i);
			k=0;
			while (k<6){
				if(i ==5){
					k=4;
				}
				v = (ImageView) row.getChildAt(k);
				v.setTag(color+values[j]);
				id =Jacks.getDrawable(context, color+values[j]);
				v.setImageResource(id);
				k+=2;
				j++;
			}
			i++;
		}
	}
	@Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        // Verify that the host activity implements the callback interface
        try {
            // Instantiate the NoticeDialogListener so we can send events to the host
            mListener = (OnSubmitListener) activity;
        } catch (ClassCastException e) {
            // The activity doesn't implement the interface, throw exception
            throw new ClassCastException(activity.toString()
                    + " must implement OnSubMitListener");
        }
    }
	@Override
	public Dialog onCreateDialog(Bundle savedInstanceState) {

		final  Dialog dialog = new Dialog(getActivity());
		dialog.getWindow().requestFeature(Window.FEATURE_NO_TITLE);
		dialog.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		dialog.setContentView(R.layout.card_picker);
		Window window = dialog.getWindow();
		window.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
				ViewGroup.LayoutParams.WRAP_CONTENT);
		dialog.getWindow().setBackgroundDrawable(
				new ColorDrawable(Color.TRANSPARENT));
		dialog.show();
		//Adding onClickListeners to buttons
		TableRow r = (TableRow) dialog.findViewById(R.id.tableRowC);

		OnClickListener suitButton =new OnClickListener(){
			@Override
			public void onClick(View v){
				uncheckSuit(dialog,v);
				changeColor(dialog,v);
			}
		};
		int i =1;

		while(i<8){
			RadioButton rb = (RadioButton) r.getChildAt(i);
			rb.setOnClickListener(suitButton);
			i+=2;
		}
		OnClickListener numButton = new OnClickListener(){
			@Override
			public void onClick (View v){
				String card = suit +v.getTag().toString();
				mListener.cardSelected(card,orgin);
				dismiss();
			}
		};
		TableLayout tl = (TableLayout) dialog.findViewById(R.id.tl);
		i=1;//start at 1 to skip the suitRow
		int k =1;
		while(i<6){
			r =	(TableRow) tl.getChildAt(i);
			k=1;
			while(k<6){
				if(i == 5){
					//only want to run once on row 5
					k=5;
				}
				RadioButton rb = (RadioButton) r.getChildAt(k);
				rb.setOnClickListener(numButton);
				k+=2;
			}
			i++;
		}
		//	    TextView msg = (TextView) dialog.findViewById(R.id.popupMsg);
		//	    Button btn = (Button) dialog.findViewById(R.id.navBtn);
		//	    title.setText(Title);
		//	    msg.setText(content);
		//	    btn.setOnClickListener(new OnClickListener() {
		//
		//	        @Override
		//	        public void onClick(View v) {
		//	            mListener.setOnAlert(content);
		//	            dismiss();
		//	        }
		//	    });
		return dialog;
	}	    
}

