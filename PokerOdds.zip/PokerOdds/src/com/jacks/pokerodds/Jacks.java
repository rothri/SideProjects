package com.jacks.pokerodds;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;

import com.jacks.pokerodds.R;

import junit.framework.Assert;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;


public class Jacks extends Activity implements OnSubmitListener {
	private static int gamestate;
	private static int card1;
	private static int card2;
	private static int card3;
	private static int card4;
	private static int card5;
	private boolean hold1;
	private boolean hold2;
	private boolean hold3;
	private boolean hold4;
	private boolean hold5;
	private int bet;
	private int tableid;
	private int handvalue;
	private double money;
	private static int[] deck;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_jacks);
		File prize = new File(getFilesDir(),"prize");
		if (!prize.exists()){
			prize.mkdir();
		}
		File prizetxt=new File(prize,"prize.txt");
		filewrite(0,prizetxt);
		tableid=0;
		popTable(prizetxt);
		handvalue=0;
		gamestate=0;
		card1=0;
		card2=0;
		card3=0;
		card4=0;
		card5=0;
		hold1=false;
		hold2=false;
		hold3=false;
		hold4=false;
		hold5=false;
		bet=0;
		deck=initial(deck);//also initializes bet
		money=20;
		TextView tv= (TextView) findViewById(R.id.textView7);
		tv.setText("$"+Double.toString(money));

		android.view.View.OnLongClickListener lcv = new View.OnLongClickListener() {

			@Override
			public boolean onLongClick(View v) {
				showDialog(v);
				return true;
			}
		};
		ImageView iv =(ImageView) findViewById(R.id.imageView1);
		iv.setOnLongClickListener(lcv);
		iv.setClickable(false);
		iv.setLongClickable(false);
		iv =(ImageView) findViewById(R.id.imageView2);
		iv.setOnLongClickListener(lcv);
		iv.setLongClickable(false);
		iv.setClickable(false);
		iv =(ImageView) findViewById(R.id.imageView3);
		iv.setOnLongClickListener(lcv);
		iv.setLongClickable(false);
		iv.setClickable(false);
		iv =(ImageView) findViewById(R.id.imageView4);
		iv.setOnLongClickListener(lcv);
		iv.setLongClickable(false);
		iv.setClickable(false);
		iv =(ImageView) findViewById(R.id.imageView5);
		iv.setOnLongClickListener(lcv);
		iv.setLongClickable(false);
		iv.setClickable(false);

	}
	public int[] initial (int[] array){
		array= new int[52];
		int i=0;
		while (i<52){
			array[i]=i+1;
			i+=1;
		}
		//initialize bet
		bet=1;
		TextView tv1= (TextView)findViewById(R.id.textView1);
		String text="Bet:";
		String bettext= Integer.toString(bet);
		tv1.setText(text+bettext);
		tv1.setVisibility(View.VISIBLE);
		i=0;
		while(i<9){
			TableLayout tl= (TableLayout) findViewById(R.id.hand);
			TableRow row= (TableRow)tl.findViewById(i);
			TextView tv= (TextView) row.findViewWithTag(bet);
			tv.setBackgroundColor(Color.parseColor("#F50505"));
			i+=1;
		}

		while(i<9){
			// example code for me
			// TextView change = (TextView) row.findViewWithTag(4);
			//change.setText("bob");
			TableLayout tl= (TableLayout) findViewById(R.id.hand);
			TableRow row= (TableRow)tl.findViewById(i);
			TextView tv= (TextView) row.findViewWithTag(bet);
			tv.setBackgroundColor(Color.parseColor("#F50505"));
			i+=1;
		}
		return array;
	}
	public void popTable(File prize){
		try{


			FileReader fr = new FileReader(prize);
			BufferedReader text = new BufferedReader(fr);
			String[] values = new String[6];
			try {
				int i = 0;
				int lines=0;
				while (lines!=54){
					values[i]=text.readLine();
					i+=1;
					if (i%6==0){
						addrow(values);
						i=0;
					}
					lines+=1;
				}
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				Toast.makeText(this, "I/O EXCEPTION", Toast.LENGTH_LONG).show();	
			}

		}
		catch(FileNotFoundException e){
			Toast.makeText(this, "FileNotFound?!?!", Toast.LENGTH_LONG).show();	
		}
		ImageView iv = (ImageView) findViewById(R.id.imageView1);
		iv.setClickable(false);
		iv.setLongClickable(false);
		iv = (ImageView)findViewById(R.id.imageView2);
		iv.setClickable(false);
		iv.setLongClickable(false);
		iv = (ImageView)findViewById(R.id.imageView3);
		iv.setClickable(false);
		iv.setLongClickable(false);
		iv = (ImageView)findViewById(R.id.imageView4);
		iv.setClickable(false);
		iv.setLongClickable(false);
		iv = (ImageView)findViewById(R.id.imageView5);
		iv.setClickable(false);
		iv.setLongClickable(false);
	}
	public void filewrite(int value,File prize){
		if (value==0){
			try{
				PrintWriter pw = new PrintWriter(prize);
				String[] values=new String[]{

						"ROYAL FLUSH................................................................................................................................",
						"250 ","500 ","750 ","1000 ","4000 ",
						"STRAIGHT FLUSH...............................................................................................................................",
						"50 ","100 ","150 ","200 ","250 ",
						"FOUR OF A KIND................................................................................................................................",
						"25 ","50 ","75 ","100 ","125 ",
						"FULL HOUSE.....................................................................................................................................",
						"9 ","18","27 ","36 ","45 ",
						"FLUSH...............................................................................................................................................",
						"6 ","12 ","18 ","24 ","30 ",
						"STRAIGHT........................................................................................................................................",
						"4 ","8 ","12 ","16 ","20 ",
						"3 OF A KIND........................................................................................................................................"
						,"3 ","6 ","9 ","12 ","15 ",
						"TWO PAIR..........................................................................................................................................."
						,"2 ","4 ","6 ","8 ","10 ",
						"JACKS OR BETTER.................................................................................................................."
						,"1 ","2 ","3 ","4 ","5 "

				};
				for (String x : values){
					pw.println(x);
				}
				pw.close();

			}
			catch(FileNotFoundException e){
				Toast.makeText(this, "FileNotFound?!?!", Toast.LENGTH_LONG).show();	
			}
		}
	}
	public void addrow(String[] values){
		TableLayout hand = (TableLayout) findViewById(R.id.hand);
		TableRow row= new TableRow(this);
		TableLayout.LayoutParams lp = new TableLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.MATCH_PARENT,1);
		row.setLayoutParams(lp);
		row.setId(tableid);
		tableid+=1;
		row.setWeightSum(8.5f);

		DisplayMetrics metrics = this.getResources().getDisplayMetrics();
		float density=metrics.density;


		float dp=1f;
		int pixels1 =dp2pixel(dp,density);

		dp=2f;
		int pixels2 =dp2pixel (dp,density);

		dp=125f;
		int pixels125= dp2pixel (dp,density);
		int textsize=10;
		int i=0;
		for (String value:values){
			TextView tv = new TextView(this);
			tv.setText(value);
			tv.setTextSize(textsize);
			tv.setTag(i);
			tv.setTypeface(null, Typeface.BOLD);
			tv.setTextColor(Color.parseColor("#FFFF00"));
			tv.setBackgroundColor(Color.parseColor("#020824"));
			if (i==0){
				//first column is different. name
				TableRow.LayoutParams params = new TableRow.LayoutParams(pixels125,TableRow.LayoutParams.MATCH_PARENT,2.5f);
				params.setMargins(pixels2, 0, pixels1, 0);
				tv.setGravity(Gravity.TOP);
				tv.setLayoutParams(params);
				tv.setSingleLine();
				row.addView(tv,params);
			}
			else{
				//width, height, weight
				TableRow.LayoutParams params = new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,TableRow.LayoutParams.MATCH_PARENT,1f);
				params.setMargins(pixels1, 0, pixels1, 0);
				tv.setGravity(Gravity.RIGHT);
				tv.setLayoutParams(params);
				row.addView(tv,params);
			}
			i+=1;
		}
		//Last Row for percentages
		TextView tv = new TextView(this);
		TableRow.LayoutParams params =  new TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT,TableRow.LayoutParams.MATCH_PARENT,1f);
		params.setMargins(pixels1,0,pixels2,0);
		tv.setLayoutParams(params);
		tv.setGravity(Gravity.RIGHT);
		tv.setTag(6);
		tv.setText("%");
		tv.setTextSize(textsize);
		tv.setTextColor(Color.parseColor("#FFFF00"));
		tv.setBackgroundColor(Color.parseColor("#020824"));
		row.addView(tv);

		// TextView change = (TextView) row.findViewWithTag(4);
		//change.setText("bob");
		hand.addView(row);
	}
	public int dp2pixel(float dp,float density){
		float fpixels = density*dp;
		int pixels = (int) (fpixels +0.5f);
		return pixels;
	}
	void showDialog(View v) {

		// DialogFragment.show() will take care of adding the fragment
		// in a transaction.  We also want to remove any currently showing
		// dialog, so make our own transaction and take care of that here.
		FragmentTransaction ft = getFragmentManager().beginTransaction();
		Fragment prev = getFragmentManager().findFragmentByTag("dialog");
		if (prev != null) {
			ft.remove(prev);
		}
		ft.addToBackStack(null);

		// Create and show the dialog.
		customDialog newFragment = new customDialog(this,v.getId());
		newFragment.show(ft, "dialog");
	}
	public void cardSelected(String s,int id){
		int card = card2Num(s);
		if(card ==card1 || card == card2 || card == card3 || card == card4 || card ==card5){
			Toast.makeText(this, "Card is already in play", Toast.LENGTH_LONG).show();
		}
		else{
			for(int i=0;i<52;i++){
				if( deck[i] == card){
					switch(id){
					case R.id.imageView1:
						deck[i]=card1;
						card1=card;
						deck[0]=card;
						break;
					case R.id.imageView2:
						deck[i]=card2;
						card2=card;
						deck[1]=card;
						break;
					case R.id.imageView3:
						deck[i]=card3;
						card3=card;
						deck[2]=card;
						break;
					case R.id.imageView4:
						deck[i]=card4;
						card4=card;
						deck[3]=card;
						break;
					case R.id.imageView5:
						deck[i]=card5;
						card5=card;
						deck[4]=card;
						break;
					default:
						Toast.makeText(this, "Card Not Found!", Toast.LENGTH_LONG).show();
						break;
					}
					break;
				}
			}
			showcards();
			detecthand();
			probabilities();
		}
	}
	private int card2Num(String card){
		//not the same card as num2card i believe
		String suit =card.substring(0,1);
		int num =0;
		if (suit.equals( "s")){
			num+=39;
		}
		if(suit.equals("d")){
			num+=13;
		}
		if(suit.equals("h")){
			num+=26;
		}
		String val= card.substring(1, 2);
		if (val.equals("0")){
			return num+10;
		}
		if (val.equals("j")){
			return num+11;
		}
		if(val.equals("q")){
			return num+12;
		}
		if(val.equals("k")){
			return num+13;
		}
		int value =Integer.parseInt(card.substring(1));

		return num+value;
	}
	public int[] shuffle(int[] array){
		//Fischer-Yates
		int i,j,k,n,t;
		//iterator,placeholder,placeholder,number of repeats,temp
		n=2000;
		for (i=0; i<n; i++){
			//int automatically floors values
			k= (int) (52*Math.random());
			j= (int) (52*Math.random());
			t= array[k];
			array[k]=array[j];
			array[j]=t;
		}
		return array;
	}
	public static int getDrawable(Context context, String name)
	{//Thank you Stack OverFlow
		Assert.assertNotNull(context);
		Assert.assertNotNull(name);

		return context.getResources().getIdentifier(name,
				"drawable", context.getPackageName());
	}
	public void showcards(){
		ImageView c= (ImageView) findViewById(R.id.imageView1);
		String name= num2card(card1);

		int id=getDrawable(this,name);
		c.setImageResource(id);

		c=(ImageView) findViewById(R.id.imageView2);
		name= num2card(card2);
		id=getDrawable(this,name);
		c.setImageResource(id);

		c=(ImageView) findViewById(R.id.imageView3);
		name= num2card(card3);
		id=getDrawable(this,name);
		c.setImageResource(id);

		c=(ImageView) findViewById(R.id.imageView4);
		name= num2card(card4);
		id=getDrawable(this,name);
		c.setImageResource(id);

		c=(ImageView) findViewById(R.id.imageView5);
		name= num2card(card5);
		id=getDrawable(this,name);
		c.setImageResource(id);

	}

	public String num2card(int num){
		int suitnum= (num-1)/13;
		String suit="0";
		String stringnum="0";
		if (suitnum ==0){//-1/13 is 0 so no worries
			suit="c";
		}
		if (suitnum==1){
			suit="d";
		}
		if (suitnum==2){
			suit="h";
		}
		if (suitnum==3){
			suit="s";
		}

		if (num%13<10){
			stringnum=Integer.toString(num%13);
		}
		if (num%13==10){
			stringnum="0";
		}
		if (num%13==11){
			stringnum="j";
		}
		if (num%13==12){
			stringnum="q";
		}
		if (num%13==0){
			stringnum="k";
		}
		String answer=suit+stringnum;
		if (answer=="00"){
			Toast.makeText(this, "There has been an error!", Toast.LENGTH_LONG).show();	
		}
		return answer;
	}
	public void sethold1(View view){

		// been a while since i coded, guess i am going to pick back up again. Javascript broke me
		// but then i recovered.
		// need to get Pumped! LETS WRITE SOME CODE! FUCK YEAH!
		//THIS MOTHERFUCKING CODE IS GOING TO BE SWEET.
		TextView tv=(TextView) findViewById(R.id.textView2);
		if (!hold1){//because i dont like things simple
			hold1=true;
			tv.setVisibility(View.VISIBLE);
			probabilities();
		}
		else{
			hold1=false;
			tv.setVisibility(View.INVISIBLE);
			probabilities();
		}
	}
	public void sethold2(View view){
		TextView tv=(TextView) findViewById(R.id.textView3);
		if (!hold2){//because i dont like things simple
			hold2=true;
			tv.setVisibility(View.VISIBLE);
			probabilities();
		}
		else{
			hold2=false;
			tv.setVisibility(View.INVISIBLE);
			probabilities();
		}
	}
	public void sethold3(View view){
		TextView tv=(TextView) findViewById(R.id.textView4);
		if (!hold3){//because i dont like things simple
			hold3=true;
			tv.setVisibility(View.VISIBLE);
			probabilities();
		}
		else{
			hold3=false;
			tv.setVisibility(View.INVISIBLE);
			probabilities();
		}
	}
	public void sethold4(View view){
		TextView tv=(TextView) findViewById(R.id.textView5);
		if (!hold4){//because i dont like things simple
			hold4=true;
			tv.setVisibility(View.VISIBLE);
			probabilities();
		}
		else{
			hold4=false;
			tv.setVisibility(View.INVISIBLE);
			probabilities();
		}
	}
	public void sethold5(View view){
		TextView tv=(TextView) findViewById(R.id.textView6);
		if (!hold5){//because i dont like things simple
			hold5=true;
			tv.setVisibility(View.VISIBLE);
			probabilities();
		}
		else{
			hold5=false;
			tv.setVisibility(View.INVISIBLE);
			probabilities();
		}
	}
	public void incbet(View view){
		int i=0;

		if (bet!=0){
			while(i<9){
				// example code for me
				// TextView change = (TextView) row.findViewWithTag(4);
				//change.setText("bob");
				TableLayout tl= (TableLayout) findViewById(R.id.hand);
				TableRow row= (TableRow)tl.findViewById(i);
				TextView tv= (TextView) row.findViewWithTag(bet);
				tv.setBackgroundColor(Color.parseColor("#020824"));
				i+=1;
			}
			bet+=1;
			if(bet>5){
				bet=1;
			}

			TextView tv1= (TextView)findViewById(R.id.textView1);
			String text="Bet:";
			String bettext= Integer.toString(bet);
			tv1.setText(text+bettext);

			i=0;
			while(i<9){
				// example code for me
				// TextView change = (TextView) row.findViewWithTag(4);
				//change.setText("bob");
				TableLayout tl= (TableLayout) findViewById(R.id.hand);
				TableRow row= (TableRow)tl.findViewById(i);
				TextView tv= (TextView) row.findViewWithTag(bet);
				tv.setBackgroundColor(Color.parseColor("#F50505"));
				i+=1;
			}
		}
		//bet==0
		else{
			bet=1;
			TextView tv1= (TextView)findViewById(R.id.textView1);
			String text="Bet:";
			String bettext= Integer.toString(bet);
			tv1.setText(text+bettext);
			tv1.setVisibility(View.VISIBLE);

			while(i<9){
				// example code for me
				// TextView change = (TextView) row.findViewWithTag(4);
				//change.setText("bob");
				TableLayout tl= (TableLayout) findViewById(R.id.hand);
				TableRow row= (TableRow)tl.findViewById(i);
				TextView tv= (TextView) row.findViewWithTag(bet);
				tv.setBackgroundColor(Color.parseColor("#F50505"));
				i+=1;
			}
		}

	}
	public void maxbet(View view){
		int i=0;
		// same as incbet just setting to 5
		while(i<9){
			// example code for me
			// TextView change = (TextView) row.findViewWithTag(4);
			//change.setText("bob");
			TableLayout tl= (TableLayout) findViewById(R.id.hand);
			TableRow row= (TableRow)tl.findViewById(i);
			TextView tv= (TextView) row.findViewWithTag(bet);
			tv.setBackgroundColor(Color.parseColor("#020824"));
			i+=1;
		}
		bet=5;

		TextView tv1= (TextView)findViewById(R.id.textView1);
		String text="Bet:";
		String bettext= Integer.toString(bet);
		tv1.setText(text+bettext);
		tv1.setVisibility(View.VISIBLE);

		i=0;
		while(i<9){
			// example code for me
			// TextView change = (TextView) row.findViewWithTag(4);
			//change.setText("bob");
			TableLayout tl= (TableLayout) findViewById(R.id.hand);
			TableRow row= (TableRow)tl.findViewById(i);
			TextView tv= (TextView) row.findViewWithTag(bet);
			tv.setBackgroundColor(Color.parseColor("#F50505"));
			i+=1;
		}	
	}
	public void pay(){
		if(money>bet){
			money=money-bet;
			TextView tv2=(TextView) findViewById(R.id.textView7);
			tv2.setText("$"+Double.toString(money));
		}
		else{
			Toast.makeText(this, "Out of Money, Rebuying for 100", Toast.LENGTH_LONG).show();
			money=money-bet+100;
			TextView tv2=(TextView) findViewById(R.id.textView7);
			tv2.setText("$"+Double.toString(money));
		}
	}
	public void prize(){
		if (handvalue!=-1){
			TableLayout tl= (TableLayout) findViewById(R.id.hand);
			TableRow row= (TableRow)tl.findViewById(handvalue);
			TextView tv= (TextView) row.findViewWithTag(bet);
			double prize=Integer.parseInt((tv.getText().toString()).trim());
			//text>string>int>double
			money+=prize;
			TextView tv2=(TextView) findViewById(R.id.textView7);
			tv2.setText("$"+Double.toString(money)+"0");
			///reset hand holds
		}

		if (hold1){
			hold1=false;
			TextView tv1=(TextView) findViewById(R.id.textView2);
			tv1.setVisibility(View.INVISIBLE);
		}
		if (hold2){
			hold2=false;
			TextView tv1=(TextView) findViewById(R.id.textView3);
			tv1.setVisibility(View.INVISIBLE);
		}
		if (hold3){
			hold3=false;
			TextView tv1=(TextView) findViewById(R.id.textView4);
			tv1.setVisibility(View.INVISIBLE);
		}
		if (hold4){
			hold4=false;
			TextView tv1=(TextView) findViewById(R.id.textView5);
			tv1.setVisibility(View.INVISIBLE);
		}
		if (hold5){
			hold5=false;
			TextView tv1=(TextView) findViewById(R.id.textView6);
			tv1.setVisibility(View.INVISIBLE);
		}


	}
	public void detecthand(){
		boolean straight=true;
		boolean flush=true;
		handvalue=-1;
		int num1= card1%13;
		int num2= card2%13;
		int num3= card3%13;
		int num4= card4%13;
		int num5= card5%13;
		int[] hand ={num1,num2,num3,num4,num5};
		int i=0;
		int j=0;
		int matches=0;
		int rank=5;
		//7=pair
		//9=2pair
		//11=3of a kind
		//13=full house
		//17= four of a kind
		while(i<5){
			j=0;

			while(j<5){

				if (hand[i]==hand[j]){
					matches+=1;
					if (i!=j){
						rank=hand[i];
						//only overwritten by the same pair
						//or if there is 2 pairs
					}
				}

				j+=1;
			}

			i+=1;
		}
		//straight
		Arrays.sort(hand);

		if (hand[0]!=0){
			i=1;
			while(i<5){
				if (hand[i-1]+1 !=hand[i]){
					straight=false;
					break;
				}
				i+=1;
			}
		}
		else{
			straight=false;
			if (hand[1]==1 && hand[2]==10){//hand[0] is king hand[1] is ace and hand[2] is 10
				i=3;
				straight=true;
				while(i<5){
					if (hand[i-1]+1 !=hand[i]){
						straight=false;
						break;
					}
					i+=1;
				}
			}
		}
		//flush
		int suit= (card1-1)/13;

		if(suit!=(card2-1)/13){
			flush=false;
		}
		if(suit!=(card3-1)/13){
			flush=false;
		}
		if(suit!=(card4-1)/13){
			flush=false;
		}
		if(suit!=(card5-1)/13){
			flush=false;
		}
		//im a lazy person



		TextView tv= (TextView) findViewById(R.id.textView8);
		tv.setVisibility(View.INVISIBLE);


		if (rank>10){
			tv.setText("JACKS OR BETTER");
			tv.setVisibility(View.VISIBLE);
			handvalue=8;
		}
		if (rank==0){
			tv.setText("JACKS OR BETTER");
			tv.setVisibility(View.VISIBLE);
			handvalue=8;
		}
		if (rank==1){
			tv.setText("JACKS OR BETTER");
			tv.setVisibility(View.VISIBLE);
			handvalue=8;
		}
		if (matches==9){
			tv.setText("TWO PAIR");
			tv.setVisibility(View.VISIBLE);
			handvalue=7;
		}
		if (matches==11){
			tv.setText("THREE OF A KIND");
			tv.setVisibility(View.VISIBLE);
			handvalue=6;
		}
		if(straight){
			tv.setText("STRAIGHT");
			tv.setVisibility(View.VISIBLE);
			handvalue=5;
		}
		if(flush){
			tv.setText("FLUSH");
			tv.setVisibility(View.VISIBLE);
			handvalue=4;
		}
		if (matches==13){
			tv.setText("FULL HOUSE");
			tv.setVisibility(View.VISIBLE);
			handvalue=3;
		}
		if (matches==17){
			tv.setText("FOUR OF A KIND");
			tv.setVisibility(View.VISIBLE);
			handvalue=2;
		}
		if(straight&&flush){
			tv.setText("STRAIGHT FLUSH");
			tv.setVisibility(View.VISIBLE);
			handvalue=1;
			if (hand[1]==1){
				tv.setText("ROYAL FLUSH");
				tv.setVisibility(View.VISIBLE);
				handvalue=0;
			}
		}
	}
	public void draw(View view){
		if (gamestate==0){
			pay();
			gamestate=1;
			deck=shuffle(deck);
			card1=deck[0];
			card2=deck[1];
			card3=deck[2];
			card4=deck[3];
			card5=deck[4];
			showcards();
			detecthand();
			probabilities();
			Button draw = (Button)findViewById(R.id.button6);
			draw.setText("Draw");
			Button b= (Button) findViewById(R.id.button4);
			b.setClickable(false);
			b.setVisibility(View.INVISIBLE);
			b= (Button) findViewById(R.id.button5);
			b.setClickable(false);
			b.setVisibility(View.INVISIBLE);
			ImageView iv = (ImageView) findViewById(R.id.imageView1);
			iv.setClickable(true);
			iv.setLongClickable(true);
			iv = (ImageView)findViewById(R.id.imageView2);
			iv.setClickable(true);
			iv.setLongClickable(true);
			iv = (ImageView)findViewById(R.id.imageView3);
			iv.setClickable(true);
			iv.setLongClickable(true);
			iv = (ImageView)findViewById(R.id.imageView4);
			iv.setClickable(true);
			iv.setLongClickable(true);
			iv = (ImageView)findViewById(R.id.imageView5);
			iv.setClickable(true);
			iv.setLongClickable(true);
		}
		else{
			gamestate=0;
			if(!hold1){
				card1=deck[5];
			}
			if(!hold2){
				card2=deck[6];
			}
			if(!hold3){
				card3=deck[7];
			}
			if(!hold4){
				card4=deck[8];
			}
			if(!hold5){
				card5=deck[9];
			}
			showcards();
			detecthand();
			prize();
			Button draw = (Button)findViewById(R.id.button6);
			draw.setText("Deal");
			Button b= (Button) findViewById(R.id.button4);
			b.setClickable(true);
			b.setVisibility(View.VISIBLE);
			b= (Button) findViewById(R.id.button5);
			b.setClickable(true);
			b.setVisibility(View.VISIBLE);
			ImageView iv = (ImageView) findViewById(R.id.imageView1);
			iv.setClickable(false);
			iv.setLongClickable(false);
			iv = (ImageView)findViewById(R.id.imageView2);
			iv.setClickable(false);
			iv.setLongClickable(false);
			iv = (ImageView)findViewById(R.id.imageView3);
			iv.setClickable(false);
			iv.setLongClickable(false);
			iv = (ImageView)findViewById(R.id.imageView4);
			iv.setClickable(false);
			iv.setLongClickable(false);
			iv = (ImageView)findViewById(R.id.imageView5);
			iv.setClickable(false);
			iv.setLongClickable(false);
		}

	}
	public static double nchooser(int x, int y) {
		//help from stack overflow here
		if (y < 0 || y > x) return 0;
		if (y > x/2) {
			// choose(n,k) == choose(n,n-k), 
			// so this could save a little effort
			y = x - y;
		}

		double denominator = 1.0, numerator = 1.0;
		for (int i = 1; i <= y; i++) {
			denominator *= i;
			numerator *= (x + 1 - i);
		}
		return numerator / denominator;
	}
	public double hypergeo(int object1, int object2,int n, int x){
		/** Returns probability of getting exactly x of object1
		 * with n draws from a pool made of object1 and object2
		 * SAMPLE SIZE IS OBJECT1+OBJECT2
		 **/
		double option1= nchooser(object1,x);
		double option2= nchooser(object2,(n-x));
		double num= option1*option2*1.0;
		double denum= nchooser(object1+object2,n)*1.0;
		double answer=num/denum;
		return (answer);
	}
	public double pair(int[] hand,int[] kepthand,int draw){
		int i=0;
		int j=0;
		int valueAmountHeld[]={0,0,0,0};
		int[] values = {0,1,11,12};//KAJQ
		int[] valueAmount={4,4,4,4};
		double pair=0;
		while(i<5){
			while (j<4){
				if (hand[i]%13==values[j]){
					valueAmount[j]-=1;
				}
				if (kepthand[i]%13==values[j]){
					valueAmountHeld[j]+=1;
				}
				j+=1;
			}
			j=0;
			i+=1;
		}
		i=0;
		while(i<4){
			if (valueAmountHeld[i]>=2){
				if (valueAmountHeld[i]==2){
					pair=1;
					return pair;
				}
				else{
					pair=0;
					return pair;
				}
			}
			if(draw>=(2-valueAmountHeld[i])){
				//this really needs more comments
				pair+=hypergeo(valueAmount[i],47-valueAmount[i],draw,2-valueAmountHeld[i]);
			}
			i+=1;
			// returns probability of getting exactly x of object1
			// object1,object2,n,x
		}
		return pair;
	}
	public double twoPair(int[] hand,int[]kepthand, int draw){
		int match =0;
		int[] handCardsLeft={4,4,4,4,4};

		for(int i=0;i<5;i++){
			for(int k=0;k<5;k++){
				if (hand[i]%13==hand[k]%13){
					match+=1;
					handCardsLeft[k]--;
				}
			}
		}
		//7=pair
		//9=2pair
		//11=3of a kind
		//13=full house
		//17= four of a kind
		int[] values ={0,0,0,0};//sets of Value cards with 1,2,3,4 remaining in deck
		switch(match){
		case 7:
			// int[] values= new int[]{0,1,3,9};
			values[1]=1;
			values[2]=3;
			values[3]=9;
			break;
		case 9:
			//int[] values={0,2,1,10};
			values[1]=2;
			values[2]=1;
			values[3]=10;
			break;
		case 11:
			//int[] values={1,0,2,10};
			values[0]=1;
			values[2]=2;
			values[3]=10;
			break;
		case 13:
			//int[] values ={1,1,0,11};
			values[0]=1;
			values[1]=1;
			values[3]=11;
			break;
		case 17:
			//int[] values ={0,0,1,11};
			values[2]=1;
			values[3]=11;
			break;
		default:
			values[2]=5;
			values[3]=8;
		}
		if (draw==5){
			//using multivariate hypergeo ie for default (4 choose 2 4 choose 2 *39 choose 1 /47 choose 5)*8choose2
			// + 3 choose 2 *4 choose 2 *40 choose 1 / 47 choose 5 * 5 choose 1 * 8 choose 1
			// + 3 choose 2 * 3 choose 2 * 41 choose 1 / 47 choose 5 *5 choose 2
			int[][] combin = combinator(values);
			int i =0;
			double answer =0;
			int val1 = 0;
			int val2 =0;
			while(combin[i][0] != 0 && i<24){
				val1 =combin[i][0];
				val2 = combin[i][1];
				if(val1 ==val2){
					answer+=((nchooser(val1,2)*nchooser(val2,2)*(47-val1 -val2))*nchooser(values[val1-1],2));
				}
				else{
					answer = answer +((nchooser(val1,2)*nchooser(val2,2)*(47-val1 -val2))*values[val1-1]*values[val2-1]);
				}
				i++;
			}
			answer= answer/nchooser(47,5);
			return answer;
		}
		//answers seem a little fishy for draw =4
		if(draw== 4){
			//needs to include odds of drawing 2 pair not including held card
			// plus odds of pairing held card and drawing another pair
			// and another random card
			int place=-1; //keeps track of the place of the card being held
			for (int i=0; i<5; i++){
				if(kepthand[i]!=-1){
					if(handCardsLeft[i]!=0){
						values[handCardsLeft[i]-1]--;
						place=i;
					}
					break;
				}
			}
			int[][] combin = combinator(values);
			double answer =0;
			int val1 = 0;
			int val2 =0;
			int i =0;
			while(combin[i][0] != 0 && i<24){
				val1 =combin[i][0];
				val2 = combin[i][1];
				// odds for drawing 2 pairs not including card
				if(val1 ==val2){
					answer+=((nchooser(val1,2)*nchooser(val2,2))*nchooser(values[val1-1],2));
				}
				else{
					answer = answer +((nchooser(val1,2)*nchooser(val2,2))*values[val1-1]*values[val2-1]);
				}
				i++;
			}
			//plus odds for pairing held card and drawing a pair plus 1 other card
			i=1;
			if(place>=0){//make sure we arent dealing with holding a 4 of a kind card
				while(i<4){
					answer+= (nchooser(i+1,2)*handCardsLeft[place]*(46-i-handCardsLeft[place]))*values[i];
					i++;
				}
			}
			answer=answer/nchooser(47,4);
			return answer;
		}
		if(draw == 3){
			// Holding onto a pair: find odds of drawing another pair and a card in neither pairs
			// drawing a pair and 1 card pairing with the two none paired

			//holding onto a pair
			int place =-1;
			if(match >=7){
				//first verify pair
				boolean check =true;
				for(int i =0;i<5;i++){
					if(kepthand[i]!= -1){
						if(place<0){
							place=i;
						}
						else{
							if(kepthand[place]%13 != kepthand[i]%13){
								check=false;
							}
						}
					}
				}
				//now calculate odds
				if(check){
					double answer=0;
					if(handCardsLeft[place]!=0){
						values[handCardsLeft[place]-1]--;// dont count paired values twice
					}
					for(int i=1;i<4;i++){
						answer+= (nchooser(i+1,2)*(46-i-handCardsLeft[place]))*values[i];
					}
					answer=answer/nchooser(47,3);
					return answer;
				}
			}
			//no pair held
			//first eliminate extras in values so no counting twice
			place=-1;
			int place2 = -1;
			for(int i=0;i<5;i++){
				if(kepthand[i]!=-1){
					if(place ==-1){
						place=i;
					}
					else{
						place2=i;
					}
					if(handCardsLeft[i]!=0){
						values[handCardsLeft[i]-1]--;
					}
				}
			}
			//Then calculate odds
			//Getting a pair and matching either held card 
			//or matching both held cards and drawing another unrelated card
			double answer =0;
			for (int i=1; i<4; i++){
				answer+= nchooser(i+1,2)*values[i]*(handCardsLeft[place]+handCardsLeft[place2]);
			}
			answer+= (handCardsLeft[place]*handCardsLeft[place2])*(47-handCardsLeft[place]-handCardsLeft[place2]);
			answer =answer/nchooser(47,3);
			return answer;
		}
		if(draw == 2){

			//first check to see if there is a pair
			match =14;//keeps track of which cards have and havent been seen
			int temp =14;
			boolean check =false;
			for (int i=0;i<5;i++){
				if (kepthand[i]!=-1){
					if(handCardsLeft[i]==3){
						values[handCardsLeft[i]-1]--;
					}
					if(kepthand[i]%13 == match || kepthand[i]%13 ==temp){
						if(!check && handCardsLeft[i]==2){//if there is only 1 handcard left we dont care
							values[handCardsLeft[i]-1]--;
						}
						check =true;
					}
					else{
						if(match ==14){
							match = kepthand[i]%13;
						}
						else{
							temp= kepthand[i]%13;
						}
					}
				}
			}
			if (temp ==14){
				return 0.0; //all 3 cards were the same
			}
			if(check){//holding onto a pair
				//odds of getting a pair plus odds of getting the nonpaired value and another card
				double answer =0;
				for(int i=1; i<4;i++){
					answer+= nchooser(i+1,2)*values[i];
				}
				match=-1;
				temp=-1;
				for(int i=0; i<5; i++){
					if(kepthand[i]!=-1){
						if(match != -1 && temp != -1){// i am embarrassed by this code
							if(kepthand[match]%13 == kepthand[temp]%13){
								answer+= handCardsLeft[i]*(47-handCardsLeft[i]- handCardsLeft[match]);
							}
							else{
								if(kepthand[i]%13 == kepthand[match]%13){
									answer+= handCardsLeft[temp]*(47-handCardsLeft[temp]- handCardsLeft[match]);
								}
								else{
									answer+= handCardsLeft[match]*(47-handCardsLeft[i]- handCardsLeft[match]);
								}
							}
						}
						if(match == -1){
							match=i;
						}
						else{
							temp=i;
						}
					}
				}
				answer= answer/ nchooser(47,2);
				return answer;

			}
			// not holding onto a pair or trips 3 non matching cards
			double answer =0;
			for(int i=0; i<4; i++){
				if(kepthand[i]!=-1){
					for(int j=i+1; j<5; j++){
						if(kepthand[j]!=-1){
							answer+= handCardsLeft[i]*handCardsLeft[j];
						}
					}
				}
			}
			answer = answer/nchooser(47,2);
			return answer;
		}
		if(draw == 1){
			// 2 Possibilities have 1 pair need to draw 1
			// have 2 pair need to not draw a match
			//
			//ok so how do we tell if were holding a pair
			//iterate through held cards if there is only two matches we have a held pair
			//Then hypergeo your way to victory
			//first verify pair
			match=0;
			for(int i = 0;i<5;i++){
				if(kepthand[i]!= -1){
					for(int j = 0;j<5;j++){
						if(kepthand[j]!=-1){//next time your doing this think ahead of what datatypes
							//you need and what you are going to use them for...or just write a function
							if(hand[i]%13 ==hand[j]%13){
								match++;
							}
						}
					}
				}
			}
			if(match == 6){//Guaranteed 4 matches
				//[  A J K Q]
				//[A x 0 0 0]
				//[J 0 x 0 0]
				//[K 0 0 x 0]
				//[Q 0 0 0 x]

				//use hand cards left for cards that arent a held pair
				double answer =0;
				for(int i=0; i<4; i++){
					if(kepthand[i] != -1){
						if(handCardsLeft[i] !=2){
							answer+= handCardsLeft[i];
						}
					}
				}
				answer=answer/47.0;
				return answer;
			}
			else if (match == 8){
				double answer =4;
				for(int i=0; i<4;i++){
					if(kepthand[i] !=-1){
						if(handCardsLeft[i] !=2){
							answer=3;
							break;
						}
					}
				}
				answer=answer/47.0;
				answer=1.0-answer;
				return answer;
			}
			else{//holding onto something better than a 2 pair
				// or not holding onto any pair, therefore not
				return 0.0;
			}
		}
		if(draw == 0){
			if (match == 9){
				return 1.0;
			}
			else {
				return 0.0;
			}
		}
		return 0.0;
	}
	public  int [][] combinator(int[] values){
		// takes values of total amount of cards left in the deck with 4/3/2/1 etc
		// returns an array with every possible combination of 2 of those elements including 2 of itself
		//[cardsLeft][cardsLeft] ie if row 1 of combinator == [3][2] that means the combination of cards left with 3 and 2
		//not going to return [4][3] and [3][4] together ie only unique combinations where order doesnt matter
		int [][] answer = new int[24][2];//size will be under 4!
		int row =0;// the row in answer we are filling
		for(int i =1; i<4;i++){//values[0] represents cards with 1 left in deck
			if(values[i]!=0){
				for (int j=i; j<4;j++){//iterating through the array hitting each value in combination
					//with others
					if(i == j){
						if(values[i]>1){
							answer[row][0]= i+1;
							answer[row][1]= j+1;
							row++;
						}
					}
					else{
						if(values[j] !=0){
							answer[row][0] =i+1;
							answer[row][1] =j+1;
							row++;
						}
					}
				}
			}
		}
		return answer;
	}
	public double triple (int[] hand, int[]kepthand,int draw){
		int match =0;
		int[] handCardsLeft={4,4,4,4,4};

		for(int i=0;i<5;i++){
			for(int k=0;k<5;k++){
				if (hand[i]%13==hand[k]%13){
					match+=1;
					handCardsLeft[k]--;
				}
			}
		}
		//7=pair
		//9=2pair
		//11=3of a kind
		//13=full house
		//17= four of a kind
		int[] values ={0,0,0,0};//sets of Value cards with 1,2,3,4 remaining in deck
		switch(match){
		case 7:
			// int[] values= new int[]{0,1,3,9};
			values[1]=1;
			values[2]=3;
			values[3]=9;
			break;
		case 9:
			//int[] values={0,2,1,10};
			values[1]=2;
			values[2]=1;
			values[3]=10;
			break;
		case 11:
			//int[] values={1,0,2,10};
			values[0]=1;
			values[2]=2;
			values[3]=10;
			break;
		case 13:
			//int[] values ={1,1,0,11};
			values[0]=1;
			values[1]=1;
			values[3]=11;
			break;
		case 17:
			//int[] values ={0,0,1,11};
			values[2]=1;
			values[3]=11;
			break;
		default:
			values[2]=5;
			values[3]=8;
		}
		double draw3 =0;//amount of ways to draw 3 of the same value
		double draw2 =0;// amount of ways to draw 2 cards of different value 
		double total =0;
		//given the 3 we have chosen
		if(draw==5){
			for(int i=2; i<4;i++){
				if(values[i] !=0){
					total+=values[i]*hypergeo(i+1,46-i,5,3);
					/** Returns probability of getting exactly x of object1
					 * with n draws from a pool made of object1 and object2
					 * SAMPLE SIZE IS OBJECT1+OBJECT2
					 **/
					//obj 1, obj2 , n ,x 
				}
			}
			return total;
		}
		if(draw==4){
			for(int i=0; i<5;i++){
				if (kepthand[i]!=-1){
					//fixed values so held card isnt counted twice
					if(handCardsLeft[i]!=0){
						values[handCardsLeft[i]-1]--;
					}
					draw3=nchooser(handCardsLeft[i],2);
					draw2=0;
					total=0;
					for (int j=0;j<4;j++){
						draw2+=values[j]*(j+1)*(46-j-handCardsLeft[i]);
						if(j>=2){								
							total+=values[j]
									//*(j+1)
									*nchooser((j+1),2)*(46-j-handCardsLeft[i]);
						}
					}
					total+=draw2*draw3;
					total/=nchooser(47,4);
					total=total/2;
					return total;
				}
			}
		}
		if (draw==3){
			match=14;//use it to check if were holding a pair.
			for (int i=0;i<5;i++){
				if(kepthand[i]!=-1){
					values[handCardsLeft[i]]--;//fixes values so no double count
					draw2=handCardsLeft[i];//Used if next calculation is used
					if (match == kepthand[i]%13){
						values[handCardsLeft[i]]++;
						draw3=nchooser(handCardsLeft[i],1);
						draw2=0;
						for(int j=0;j<4;j++){
							//amount of cards in that set*cards out of that set that also arent in triple
							draw2+=values[j]*(j+1)*(46-j-handCardsLeft[i]);
						}
						total=draw3*draw2;
						total/=nchooser(47,3);
						//total/=6;
						return total;
					}
					else{
						match=kepthand[i]%13;
					}
					//Seperate calculation from above

				}
			}
			total=0;
			draw3=0;
			// draw2 is set to amount of the 2nd held card siblings
			for (int i=0;i<5;i++){
				if(kepthand[i]!=-1){
					if(total!=0){//should only execute on the 2nd card
						for(int j=2;j<4;j++){
							total+=(values[j]*nchooser(j+1,3));
						}
					}
					draw3=nchooser(handCardsLeft[i],2);
					draw2=47-draw2-handCardsLeft[i];
					total+=draw2*draw3;
					draw2=handCardsLeft[i];
					// This code is sexy
				}
			}
			total/=nchooser(47,3);
			//total/=6;
			return total;
		}
		if(draw==2){
			match=2;
			for(int i=0;i<5;i++){
				if(kepthand[i]!=-1){
					for(int k=0;k<5;k++){
						if(kepthand[k]!=-1){
							if (kepthand[i]%13==kepthand[k]%13){
								match+=1;

							}
						}
					}
				}
			}
			if(match<7){
				//no pair held
				total=0;
				for(int i=0;i<5;i++){
					if(kepthand[i]!=-1){
						total+=nchooser(handCardsLeft[i],2);
					}
				}
				total=total/nchooser(47,2);
				return total;
			}
			else if (match==7){
				match=14;
				draw3=0;
				draw2=0;
				for(int i=0;i<5;i++){
					if(kepthand[i]!=-1){
						if(match==14){
							for(int k=0;k<5;k++){
								if(kepthand[k]!=-1){
									if(k!=i){
										if(kepthand[i]%13==kepthand[k]%13){
											match=kepthand[i]%13;
											draw3=handCardsLeft[i];
										}
									}
								}
							}
						}
						if(kepthand[i]%13!=match){
							draw2=handCardsLeft[i];
						}
					}
				}
				total+=draw3*(48-draw2-draw3);
				total=total/nchooser(47,2);
				return total;
			}
			else{
				if(match!=11){
					return 2;
				}
				total=0;
				//odds of not drawing a pair, and not drawing a value held
				for(int i=1;i<4;i++){
					total+=values[i]*nchooser(i+1,2);
					//this is wrong
				}
				total += 1*46;
				total=total/nchooser(47,2);
				total= 1-total;
				return total;
			}
		}
		if(draw==1){
			match=1;
			for(int i=0;i<5;i++){
				if(kepthand[i]!=-1){
					for(int k=0;k<5;k++){
						if(kepthand[k]!=-1){
							if (kepthand[i]%13==kepthand[k]%13){
								match+=1;

							}
						}
					}
				}
			}
			if(match!= 7 && match!=11){
				return 0.0;
			}
			else if (match==7){
				for(int i=0;i<4;i++){
					if(kepthand[i]!=-1){
						for (int k=i+1;k<5;k++){
							if (kepthand[i]%13==kepthand[k]%13){
								return handCardsLeft[i]/47.0;
							}
						}
					}
				}
			}
			else{
				total=0;
				draw3=2;
				for (int i=0;i<5;i++){
					if(kepthand[i]!=-1){
						if(handCardsLeft[i]==0){
							draw3=0;
						}
						total+=handCardsLeft[i];
					}
				}
				total=47-total+draw3;
				return total/47.0;
			}
		}
		if(draw==0){
			if (match!=11){
				return 0.0;
			}
			else{
				return 1;
			}
		}
		return 0.0;
	}

	public double straight(int[] hand,int[] kepthand,int draw){
		//no cards held
		double straightHands =0;
		int[] cards = {//Length 13
				4,4,4,4,
				4,4,4,4,
				4,4,4,4,
				4
		};
		for(int i=0; i<5;i++){
			cards[(hand[i]-1)%13]-=1;
			//Cards is now a list of amount of cards remaining
			//where Aces are cards[0] and kings are cards[12]
		}
		if(draw == 5){
			for(int i=4;i<13;i++){
				straightHands+= cards[i-4]*cards[i-3]*cards[i-2]*cards[i-1]*cards[i];
			}
			straightHands+=cards[0]*cards[12]*cards[11]*cards[10]*cards[9];
			straightHands=straightHands/nchooser(47,5);
			return straightHands;
		}
		if(draw == 4){
			int cardHeld=-1;
			for (int i=0;i<5;i++){
				if (kepthand[i]!=-1){
					cardHeld=(kepthand[i]-1)%13;
					break;
				}
			}
			switch(cardHeld){
			//negative 1 shouldn't be possible
			case 0:
				straightHands=cards[12]*cards[11]*cards[10]*cards[9];
				straightHands+=cards[1]*cards[2]*cards[3]*cards[4];
				break;
			default:
				straightHands=straightAroundCard(cardHeld,cards);
			}
			straightHands=straightHands/(nchooser(47,4));
		}
		if(draw<4){
			int[] keptCards = new int[5-draw];
			int handSize =0;
			int gap=0;
			for(int i=0;i<5;i++){
				if(kepthand[i] !=-1){
					keptCards[handSize]=(kepthand[i]-1)%13;
					handSize++;
				}
			}
			Arrays.sort(keptCards);
			for(int i=1;i<handSize;i++){
				if(keptCards[i-1]==keptCards[i]){
					return 0.0;
				}
				if(keptCards[i-1]!=0){//aces mess your day up
					gap+=(keptCards[i]-keptCards[i-1])-1;
					if(gap>draw){
						return 0.0;
					}
				}
				else{
					if(keptCards[i]<9){
						gap+=(keptCards[i]-keptCards[i-1])-1;
					}
					else{
						gap=gap+ (12-keptCards[keptCards.length -1]);
					}
					if(gap>draw){
						return 0.0;
					}
				}
			}
			if(gap!=0){
				int[] requiredDraw =new int[gap];
				gap-=1;
				for(int i=1;i<handSize;i++){
					if(gap==-1){
						break;
					}
					if(keptCards[i-1]==0){
						if(keptCards[i]<9){
							if(keptCards[i]!=1){
								int count=1;
								while(gap!=-1){
									requiredDraw[gap]= keptCards[i]-count;
									gap--;
									count++;
									if(keptCards[i]-count == 0){
										break;
									}
								}
							}
						}
						else{
							if(12-keptCards[keptCards.length -1]!=0){//Ace is first card
								//king is not last
								int count=1;
								while(gap!=-1){
									requiredDraw[gap]=keptCards[keptCards.length-1]+count;
									gap--;
									if (keptCards[keptCards.length-1]+count==12){
										break;
									}
									count++;
								}
							}
						}
					}
					else{//i-1 !=0
						if(keptCards[i]-keptCards[i-1]!=1){
							int count =1;
							while(gap!=-1){
								requiredDraw[gap]=keptCards[i]-count;
								gap--;
								count++;
								if (keptCards[i]-count ==keptCards[i-1]){
									break;
								}
							}
						}
					}	
				}
				straightHands=outsideDraw(keptCards,cards,draw-requiredDraw.length);
				for(int i=0; i<requiredDraw.length;i++){
					straightHands*=cards[requiredDraw[i]];
				}
				//				for(int i=0;i<keptCards.length;i++){
				//					straightHands=straightHands*(43.0+i);
				//				}
				//				straightHands/=(47.0*46*45*44*43);
				straightHands/=nchooser(47,draw);
				return straightHands;
			}
			straightHands=outsideDraw(keptCards,cards,draw);
			//			for(int i=0;i<keptCards.length;i++){
			//				straightHands=straightHands*(43.0+i);
			//			}
			//			straightHands/=(47.0*46*45*44*43);
			straightHands/=nchooser(47,draw);
			return straightHands;
		}
		return straightHands;
	}
	public int outsideDraw(int[] cardsHeld,int[] cards,int draw){
		if(draw==0){
			return 1;
		}
		//Returns total amount of straight Draws Outside of CardsHeld
		//CardsHeld at least contains 2 cards
		int min=cardsHeld[0]-draw;
		int answer=1;
		int max=cardsHeld[cardsHeld.length-1]+draw;
		if(cardsHeld[0]==0){
			if(cardsHeld[1]<5){
				while(max!=cardsHeld[cardsHeld.length-1] ){
					answer*=cards[max];
					max--;
				}
				return answer;
			}
			else{
				min=cardsHeld[1]-draw;
				while(min!=cardsHeld[1]){
					answer*=cards[min];
					min++;
				}
				return answer;
			}
		}
		else{
			answer=0;
			int straights=1;
			int fix=0;
			for(int i=-draw;i<=0;i++){
				straights=1;
				for (int k=0;k<draw;k++){
					if(k+i ==0){
						fix=5-draw;
					}
					if(i+cardsHeld[0]<0 ){
						straights=0;
						break;
					}
					if(k+i+fix+cardsHeld[0]>12){
						straights*=cards[0];
						if(k+i+fix+cardsHeld[0]>13){
							straights=0;
							break;
						}
					}
					else{
						straights*=cards[fix+i+k+cardsHeld[0]];
					}
				}
				fix=0;
				answer+=straights;
			}
			return answer;
		}
	}
	public double straightAroundCard (int cardHeld, int[] cards){
		//Returns amount of ways to form straights around a cardHeld given cards[]left in deck
		//cards is an array[12] with array0=Amount of aces array12= amount of kings
		//cant handle cardHeld =0;
		//CardHeld is A=0 K=12
		if(cards[cardHeld]==0){
			return 0.0;//holding 1 card in a 4 of a kind
		}
		int straightSum=0;
		int straights =1;
		int fix=0;
		for(int i=-4;i<=0;i++){
			fix=0;
			for(int k=0; k<4;k++){
				if(k+i ==0){
					fix=1;
				}
				if(i+cardHeld<0 ){
					straights=0;
					break;
				}
				if(k+i+fix+cardHeld>12){
					straights*=cards[0];
					if(k+i+fix+cardHeld>13){
						straights=0;
						break;
					}
				}
				else{
					straights*=cards[k+i+fix+cardHeld];
				}
			}
			straightSum+=straights;
			straights=1;
		}
		return straightSum;
	}
	public double flush(int[] hand,int[] kepthand,int draw){
		int suit=-1;//suit of the flush
		int object1=13;//13 cards needed in the deck
		int object2=47;//start with 47 cards
		int x=5;
		//draw is n
		for (int i=0; i<5; i++){//for all cards in hand
			if (kepthand[i] != -1){//if card is held

				if (suit ==-1){//no assigned suit
					suit=(kepthand[i]-1)/13;

					for(int j=0; j<5; j++){//check discards if there are matching suits
						if ((hand[j]-1)/13==suit){
							object1-=1;
						}
					}
				}

				else{//elif
					if ((kepthand[i]-1)/13!=suit){
						return 0;
					}
				}
				x-=1;//one less card needed to make a flush
			}
		}//end of for loop
		if(x==0){//0 cards needed
			return 1;
		}
		if (suit!=-1){//there is one suit to go after
			return hypergeo(object1,(object2-object1),draw,x);
			// returns probability of getting exactly x of object1 from sample of object1+object2
			// object1,object2,n,x
		}
		else{//must be drawing 5 card, holding none
			int suitC=13;
			int suitD=13;
			int suitH=13;
			int suitS=13;
			for (int i=0; i<5; i++){//not the most efficient way
				suit=(hand[i]-1)/13;
				if (suit>1){
					if (suit==2){
						suitH-=1;
					}
					else{
						suitS-=1;
					}
				}
				else{
					if (suit==1){
						suitD-=1;
					}
					else{
						suitC-=1;
					}
				}
			}
			double sum=0;
			sum+= hypergeo(suitC,(object2-suitC),draw,x);//x should be 5
			sum+= hypergeo(suitD,(object2-suitD),draw,x);
			sum+= hypergeo(suitH,object2-suitH,draw,x);
			sum+= hypergeo(suitS,object2-suitS,draw,x);
			return sum;
		}
	}
	public double fullHouse(int[] hand, int[] keptHand,int draw){
		//3

		double answer =0.0;
		int match =0;
		int heldMatch=0;
		int[] handCardsLeft={4,4,4,4,4};

		for(int i=0;i<5;i++){
			for(int k=0;k<5;k++){
				if (hand[i]%13==hand[k]%13){
					if(keptHand[i]!=-1 && keptHand[k]!=-1){
						heldMatch++;
					}
					match+=1;
					handCardsLeft[k]--;
				}
			}
		}
		int[] values ={0,0,0,0};//sets of Value cards with 1,2,3,4 remaining in deck
		//7=pair
		//9=2pair
		//11=3of a kind
		//13=full house
		//17= four of a kind
		switch(match){
		case 7:
			// int[] values= new int[]{0,1,3,9};
			values[1]=1;
			values[2]=3;
			values[3]=9;
			break;
		case 9:
			//int[] values={0,2,1,10};
			values[1]=2;
			values[2]=1;
			values[3]=10;
			break;
		case 11:
			//int[] values={1,0,2,10};
			values[0]=1;
			values[2]=2;
			values[3]=10;
			break;
		case 13:
			//int[] values ={1,1,0,11};
			values[0]=1;
			values[1]=1;
			values[3]=11;
			break;
		case 17:
			//int[] values ={0,0,1,11};
			values[2]=1;
			values[3]=11;
			break;
		default:
			values[2]=5;
			values[3]=8;
		}
		if(draw == 5){
			int[][] combinations =combinator(values);
			int val1 = 0;
			int val2 =0;
			int i =0;
			while(combinations[i][0] != 0 && i<24){
				val1 =combinations[i][0];
				val2 = combinations[i][1];
				//so can choose 3 from 2 from other
				//3 cases both are 2, 1 is 2, neither is 2
				if(val1 ==2 || val2 ==2){
					if( val1 !=2 || val2 !=2){//only want case when 1 of them is not 2

						int temp = 0;//placeholder value so val1 is always >2
						if (val1 ==2){
							temp=val1;
							val1=val2;
							val2=temp;
						}
						//how many cards with 3/4 left * 3or4 choose 3 * cards with 2 left *2 choose 2
						answer+= values[val1-1]*nchooser(val1,3)*values[val2-1]*nchooser(val2,2);
					}
				}
				else{
					if(val1 == val2){
						answer+= values[val1-1]*(values[val1-1]-1)*nchooser(val1,3)*nchooser(val1,2);
					}
					else{
						answer+= values[val1-1]*nchooser(val1,3)*values[val2-1]*nchooser(val2,2);
						//also need to add taking 3 of val2 and 2 of val1
						answer+= values[val2-1]*nchooser(val2,3)*values[val1-1]*nchooser(val1,2);
					}
				}
				i++;//never forget to end a loop
			}
			answer=answer/(nchooser(47,5));
			return answer;
		}
		if(draw == 4){
			//held card needs to be part of 3 or 2
			int heldLeft =0;// will hold value of the number of held card's remaining matches
			for (int i=0; i<5; i++){
				if (keptHand[i] != -1){
					heldLeft = handCardsLeft[i];
					break;
				}
			}
			switch(heldLeft){
			case 0:
				return 0.0;
			case 1:
				//      cardsleft with 3 *3choose3*1 
				answer= values[2];
				//cardsleft with 4* 4 choose 3 *1
				answer+= values[3]*nchooser(4,3);
				answer=answer/(nchooser(47,4));
				return answer;
			default:
				values[heldLeft-1]--;
				for(int i=2;i<4;i++){
					answer+=values[i]*nchooser(i+1,3)*nchooser(heldLeft,1);
				}
				for (int i=1;i<4;i++){
					answer+= values[i]*nchooser(i+1,2)*nchooser(heldLeft,2);
				}
				answer=answer/(nchooser(47,4));
				return answer;
			}
		}
		if(draw == 3){
			//2 cases, they either match or they dont
			// if they match and they have at least 1 card remaining they can be part of 3 or 2
			//else they must be part of 2
			//if they dont match 1 must be part of 3 and another part of 2
			if(heldMatch >2){
				int heldLeft=0;//amount of held cards left
				for (int i=0;i<5; i++ ){
					if (keptHand[i]!=-1){
						heldLeft = handCardsLeft[i];
						break;
					}
				}
				if(heldLeft !=0){
					values[heldLeft-1]--;
					for (int i=1;i<4;i++){
						if(i>1){
							answer+= values[i]*nchooser(i+1,3);
						}
						answer+= values[i]*nchooser(i+1,2)*nchooser(heldLeft,1);
					}
					answer=answer/nchooser(47,3);
					return answer;
				}
				else{
					for(int i=2; i<4;i++){
						answer = values[i]*nchooser(i+1,3);
					}
					answer=answer/nchooser(47,3);
					return answer;
				}
			}
			//Now if the 2 held cards dont match
			int heldLeft1 =-1;
			int heldLeft2 = 0;
			for (int i=0;i<5;i++){//places cardsLeft  into heldLeft1 and 2 and subtracts from value
				if (keptHand[i] != -1){
					if( heldLeft1 == -1){
						heldLeft1 = handCardsLeft[i];
						if(heldLeft1 != 0){
							values[heldLeft1-1]--;
						}
					}
					else{
						heldLeft2 = handCardsLeft[i];
						if(heldLeft2 !=0){
							values[heldLeft2 -1]--;
						}
						break;
					}
				}
			}
			//now if either has 0 cards left return 0.0
			//if 1 of them has 1 card left it must be the 2
			// if both of them have 1 card left return 0
			//otherwise either could be the 3 or the 2
			if (heldLeft1 ==0 || heldLeft2 == 0){
				return 0.0;
			}
			if (heldLeft1 ==1 || heldLeft2 ==1){
				if(heldLeft1 ==1 && heldLeft2 ==1){
					return 0.0;
				}
				if (heldLeft1 !=1){
					//make sure heldLeft1 always has the 1
					int temp =heldLeft1;
					heldLeft1=heldLeft2;
					heldLeft2=temp;
				}
				//nchooser(card with not 1 left ,2)*nchooser(card with 1,1)
				answer = nchooser(heldLeft2,2);
				answer=answer/nchooser(47,3);
				return answer;
			}
			answer = nchooser(heldLeft1,2)*nchooser(heldLeft2,1);
			answer+= nchooser(heldLeft2,2)*nchooser(heldLeft1,1);
			answer=answer/nchooser(47,3);
			return answer;			
		}
		if(draw == 2){ 
			//has nothing return 0.0
			//has pair and 1 other card=odds drawing 2 of other card + odds of drawing 1 of other card and 1 of pair
			//has trips odds of drawing a pair

			//heldMatch distribution for 3
			//5 ==pair
			//9 ==trips
			switch(heldMatch){
			case 5:
				int cardLeftPair =-1;
				int cardLeft=-1;
				for (int i=0;i<5;i++){//this is supposed to get the right cardLeft values
					if(keptHand[i]!=-1){
						if(cardLeftPair ==-1){
							for (int j=i+1;j<5;j++){
								if(keptHand[j] == keptHand[i]){
									cardLeftPair = handCardsLeft[i];
								}
							}
							if (cardLeftPair == -1){
								cardLeft =handCardsLeft[i];
							}
						}
						else{
							if (cardLeft != -1){
								break;
							}
							if (i ==4){
								cardLeft =handCardsLeft[i];
							}
							for( int j =0; j<5;j++){
								if(keptHand[j] != -1 && i!=j){
									if (keptHand[i] != keptHand[j]){
										cardLeft = handCardsLeft[i];
										break;
									}
									else{
										break;
									}
								}
							}
						}
					}
				}
				//cardLeft
				//cardLeftPair
				if (cardLeft == 1){
					answer=nchooser(cardLeftPair,1);
					answer=answer/nchooser(47,2);
					return answer;
				}
				else{
					if(cardLeftPair !=0){
						answer=nchooser(cardLeft,1)*nchooser(cardLeftPair,1);
					}
					answer+=nchooser(cardLeft,2);
					answer=answer/nchooser(47,2);
					return answer;
				}
			case 9:
				for(int i=1;i<4;i++){
					answer+= values[i]*nchooser(i+1,2);				
				}
				answer=answer/nchooser(47,2);
				return answer;	
			default:
				return 0.0;
			}
		}
		if(draw == 1){
			//has trips and 1 other card, need to draw 1 more of the other card
			//has 2 pair and needs to draw 1 from either pair
			//has neither 2pair nor trips return 0
			switch(heldMatch){
			//8 = 2 pair
			//10 =trips
			case 8:
				int cardsLeft = -1;//tracking cards left for each pair
				int cardsLeft2 = -1;
				for (int i=0; i<5; i++){
					if (keptHand[i] !=-1){
						if (cardsLeft ==-1){
							cardsLeft = handCardsLeft[i];
						}
						if (cardsLeft != handCardsLeft[i]){
							cardsLeft2=handCardsLeft[i];
							break;
						}
					}
				}
				if (cardsLeft2 == -1){
					cardsLeft2 =cardsLeft;
				}
				answer = nchooser(cardsLeft,1)+nchooser(cardsLeft2,1);
				answer=answer/nchooser(47,1);
				return answer;
			case 10:
				for (int i=0; i<5; i++){
					if(keptHand[i]!=-1){
						if (handCardsLeft[i]>1){
							answer=handCardsLeft[i];
							break;
						}
					}
				}
				answer= answer/nchooser(47,1);
				return answer;
			default:
				return 0.0;
			}
		}
		if(match ==13){// if it doesnt return a value then there must be something wrong with how match is eval
			return 1.0;
		}
		else{
			return 0.0;
		}
	}
	public double fourKind(int[] hand, int[] keptHand,int draw){
		//1
		double answer =0.0;
		int match =0;
		int[] handCardsLeft={4,4,4,4,4};

		for(int i=0;i<5;i++){
			for(int k=0;k<5;k++){
				if (hand[i]%13==hand[k]%13){
					match+=1;
					handCardsLeft[k]--;
				}
			}
		}
		int[] values ={0,0,0,0};//sets of Value cards with 1,2,3,4 remaining in deck
		switch(match){
		case 7:
			// int[] values= new int[]{0,1,3,9};
			values[1]=1;
			values[2]=3;
			values[3]=9;
			break;
		case 9:
			//int[] values={0,2,1,10};
			values[1]=2;
			values[2]=1;
			values[3]=10;
			break;
		case 11:
			//int[] values={1,0,2,10};
			values[0]=1;
			values[2]=2;
			values[3]=10;
			break;
		case 13:
			//int[] values ={1,1,0,11};
			values[0]=1;
			values[1]=1;
			values[3]=11;
			break;
		case 17:
			//int[] values ={0,0,1,11};
			values[2]=1;
			values[3]=11;
			break;
		default:
			values[2]=5;
			values[3]=8;
		}
		if(draw ==5){
			answer= values[3]*1.0*43;
			answer=answer/nchooser(47,5);
			return answer;
		}
		if(draw == 4){
			answer=values[3];//draw 4 of a kind all different from held car
			for(int i=0;i<5;i++){
				if(keptHand[i]!= -1){
					if(handCardsLeft[i]==3){
						//draw 3 of held card and 1 other card
						answer=answer +1.0*44;
					}
				}
			}
			answer=answer/nchooser(47,4);
			return answer;
		}
		if(draw ==3){
			//ok if we have have pair need to draw 2 more and 1 random card
			//if we dont have a pair draw 3 of one of the cards we have
			boolean check = false;
			int lastCard=-1;
			for(int i=0;i<5;i++){
				if(keptHand[i]!=-1){
					if(lastCard !=-1){
						if(lastCard%13 == hand[i]%13){
							check =true;
							break;
						}
					}
					lastCard= hand[i];
				}
			}
			if(check){
				for(int i=0;i<5;i++){
					if(keptHand[i]!=-1){
						if(handCardsLeft[i]==2){//make sure that we arent holding a pair and discarding 1 
							//of its other values
							answer = 45.0;//47 cards left 2 choose 2 is 1. 45 other cards
						}
						break;//only need to check 1 held card
					}
				}
				answer=answer/nchooser(47,3);
				return answer;
			}
			else{

				for(int i=0;i<5;i++){
					if(keptHand[i]!=-1){
						if(handCardsLeft[i]==3){
							answer+= 1.0;//3 choose 3
						}
					}
				}
				answer=answer/nchooser(47,3);
				return answer;
			}
		}
		if(draw ==2){
			//have a pair
			//have trips
			//have nothing
			match =0;
			for(int i=0;i<5;i++){
				if(keptHand[i]!=-1){
					for (int k=0; k<5;k++){
						if(keptHand[k]!=-1){
							if(hand[i]%13 ==hand[k]%13){
								match ++;
							}
						}
					}
				}
			}
			//no match =3
			//pair =5
			//trips 9
			if(match ==5){
				int firstCard =-1;
				int otherCard =-1; //really should've thought this through
				for(int k=0;k<5;k++){
					if(keptHand[k]!=-1){
						if(firstCard !=-1){
							if(otherCard != -1){
								if(handCardsLeft[k]==2){
									answer=1.0;
									break;
								}
								else{
									answer=0;
									break;
								}
							}
							else{
								otherCard=hand[k];
								if(otherCard%13 ==firstCard%13){
									if(handCardsLeft[k] ==2){
										answer=1.0;
										break;
									}
									else{
										answer=0;
										break;
									}
								}
							}
						}
						else{
							firstCard =hand[k];
						}
					}
				}
				answer=answer/nchooser(47,2);
				return answer;
			}
			if(match ==9){
				for(int i=0;i<5;i++){
					if(keptHand[i]!=-1){
						if (handCardsLeft[i] ==0){
							return 0;
						}
						if(handCardsLeft[i]==1){
							break;
						}
						else{
							return 1.1;//there has been a mistake
						}
					}
				}
				answer=1.0*46;
				answer=answer/nchooser(47,2);
				return answer;
			}
			return 0.0;

		}
		if(draw ==1){
			boolean fourFlag =false; 
			//used to keep track whether hand had 4 of a kind of not
			if(match == 17){
				fourFlag =true;
			}
			//have trips or have nothing
			//  1 1 1 2 3
			//1[x x x 0 0]
			//1[x x x 0 0]
			//1[x x x 0 0]
			//2[0 0 0 x 0]
			//3[0 0 0 0 x]	
			match=0;
			for(int i=0;i<5;i++){
				if(keptHand[i] != -1){
					for(int k=0;k<5;k++){
						if (keptHand[i]%13==keptHand[k]%13){
							match+=1;
							handCardsLeft[k]--;
						}
					}
				}
			}
			if(match ==16){
				return 1.0;
			}
			if (match !=10){
				return 0;
			}
			if(fourFlag){
				return 0.0;
			}
			answer = 1.0/47.0;
			return answer;
		}
		if(match ==17){
			return 1.0;
		}
		else{
			return 0.0;
		}
	}
	public double straightFlush(int[] hand, int[] keptHand,int draw){
		//2
		int [][] Cards= new int[4][13];
		int suit =0;
		int value=0;
		for (int i=0;i<5;i++){
			if(keptHand[i] != -1){
				suit = (hand[i]-1)/13;
				value =hand[i]%13;
				Cards[suit][value]=2;
			}
			else{
				suit = (hand[i]-1)/13;
				value =hand[i]%13;
				Cards[suit][value]=1;				
			}
		}
		//king =0 ie {K,A,2,3,4,5,6,7,8,9,10,J,Q}
		//ace =1
		//queen =12
		double answer=0.0;
		for (int i=0; i<4; i++){//this section could be more efficient
			for(int j=1; j<10;j++){
				int drawCount =0;
				boolean straight =true;
				for(int k=0;k<5;k++){
					switch(Cards[i][(j+k)%13]){
					case 1:
						straight =false;
						break;
					case 2:
						drawCount++;
					}
				}
				if (straight && drawCount == (5-draw)){
					answer++;
				}
			}
		}
		answer=answer/nchooser(47,draw);
		return answer;
	}
	public double royalFlush(int[] hand, int[] keptHand,int draw){
		//4
		//%13 gives value
		// /13 gives suit
		double answer =0;
		int [] suitArr ={1,1,1,1};
		for (int i=0;i<5;i++ ){
			if (hand[i]%13 <2 || hand[i]%13>10){
				suitArr[(hand[i]-1)/13]=0;
			}
			if (keptHand[i]!=-1){
				int suit = (hand[i]-1)/13;
				if( hand[i]%13>1 && hand[i]%13<11){
					return 0.0;
				}
				for (int j=0; j<5;j++){
					if(keptHand[j] != -1){
						if( (hand[j]-1)/13 != suit){
							return 0.0;
						}
						if(hand[j]%13>1 && hand[j]%13<10){
							return 0.0;
						}
					}
					else{
						if((hand[j]-1)/13 ==suit){
							if(hand[j]%13<2 || hand[j]%13 >9){
								return 0.0;
							}
						}
					}
				}
				answer=(1/nchooser(47,draw));
				return answer;
			}
		}
		answer =0;
		for (int i=0;i<4;i++){
			answer+= suitArr[i];
		}
		answer=answer/nchooser(47,5);
		return answer;
	}
	public double[] calcAll(int[] hand,boolean[] held){
		double count =0;
		int amountHeld =0;
		//move held cards to beginning of hand
		for (int i=0; i<5;i++){
			if(held[i]){
				int temp =hand[amountHeld];
				hand[amountHeld]=hand[i];
				hand[i]=temp;
				amountHeld++;
			}
		}
		double[] odds= {0,0,0,0,0,0,0,0,0};
		int []pos={5,6,7,8,9};
		for(int i=amountHeld;i<5;i++){
			pos[i]=5+i-amountHeld;
		}
		if(amountHeld ==5){
			if(detectHand2(hand) != -1){
				odds[detectHand2(hand)]++;
				return odds;
			}
		}
		int posTracker =4;
		int lastPos=4;
		int handValue =0;
		while(pos[amountHeld]<47+amountHeld){
			if (pos[posTracker] == 52){
				for (int i=1;i<5;i++){
					if (pos[posTracker-i] != 51-i){
						int k=0;
						lastPos=posTracker-i;
						pos[lastPos]++;
						while(lastPos+k <5){
							pos[lastPos+k]= pos[lastPos]+k;
							k++;
						}
						break;
					}
				}
			}
			for(int i=amountHeld;i<5;i++){

				hand[i]=deck[pos[i]];

			}
			handValue = detectHand2(hand);
			count++;
			if (handValue != -1){
				odds[handValue]++;
			}
			pos[posTracker]++;
		}
		for (int i=0; i<9;i++){
			odds[i] = odds[i]/(nchooser(47,5-amountHeld));
		}
		count=count/nchooser(47,5-amountHeld);
		//0-51
		//need way to control draw
		return odds;
	}
	private int detectHand2(int[] passedHand){
		boolean straight=true;
		boolean flush=true;
		int num1= passedHand[0]%13;
		int num2= passedHand[1]%13;
		int num3= passedHand[2]%13;
		int num4= passedHand[3]%13;
		int num5= passedHand[4]%13;
		int[] hand ={num1,num2,num3,num4,num5};
		int i=0;
		int j=0;
		int matches=0;
		int rank=5;
		//7=pair
		//9=2pair
		//11=3of a kind
		//13=full house
		//17= four of a kind
		while(i<5){
			j=0;

			while(j<5){

				if (hand[i]==hand[j]){
					matches+=1;
					if (i!=j){
						rank=hand[i];
						//only overwritten by the same pair
						//or if there is 2 pairs
					}
				}

				j+=1;
			}

			i+=1;
		}
		//straight
		Arrays.sort(hand);

		if (hand[0]!=0){
			i=1;
			while(i<5){
				if (hand[i-1]+1 !=hand[i]){
					straight=false;
					break;
				}
				i+=1;
			}
		}
		else{
			straight=false;
			if (hand[1]==1 && hand[2]==10){//hand[0] is king hand[1] is ace and hand[2] is 10
				i=3;
				straight=true;
				while(i<5){
					if (hand[i-1]+1 !=hand[i]){
						straight=false;
						break;
					}
					i+=1;
				}
			}
		}
		//flush
		int suit= (passedHand[0]-1)/13;

		if(suit!=(passedHand[1]-1)/13){
			flush=false;
		}
		if(suit!=(passedHand[2]-1)/13){
			flush=false;
		}
		if(suit!=(passedHand[3]-1)/13){
			flush=false;
		}
		if(suit!=(passedHand[4]-1)/13){
			flush=false;
		}
		//im a lazy person



		if(straight&&flush){
			if (hand[1]==1){
				return 0;
			}
			return 1;
		}
		if (matches==17){
			return 2;
		}
		if (matches==13){
			return 3;
		}
		if(flush){
			return 4;
		}
		if(straight){
			return 5;
		}
		if (matches==11){
			return 6;
		}
		if (matches==9){
			return 7;
		}

		if (rank>10){
			return 8;
		}
		if (rank==0){
			return 8;
		}
		if (rank==1){
			return 8;
		}
		return -1;
	}
	public void probabilities(){
		//Hand is current hand of cards
		// Keep is -1 if that card is not being held, and the value of the card held if it is
		//Draw is how many cards you are going to draw
		int[] hand ={card1,card2,card3,card4,card5};
		boolean[] keep={hold1,hold2,hold3,hold4,hold5};
		int[] kepthand={-1,-1,-1,-1,-1};
		//probably a better way to do that
		int i=0;
		int draw=5;
		while (i<5){
			if(keep[i]){
				kepthand[i]=hand[i];
				draw-=1;
			}
			i++;
		}
		//jacks or better
		if(draw <4 && draw != 0){
			double[] counts =calcAll(hand,keep);
			for(  i=0;i<9;i++){
				showProb(counts[i],i);
			}
		}
		else{
			double odds= pair(hand,kepthand,draw);
			showProb(odds,8);
			odds = twoPair(hand,kepthand,draw);
			showProb(odds,7);
			odds = triple(hand,kepthand,draw);
			showProb(odds,6);
			odds =straight(hand,kepthand,draw);
			showProb(odds,5);
			odds= flush(hand,kepthand,draw);
			showProb(odds,4);
			odds = fullHouse (hand,kepthand,draw);
			showProb(odds,3);
			odds = fourKind(hand,kepthand,draw);
			showProb(odds,2);
			odds = straightFlush(hand,kepthand,draw);
			showProb(odds,1);
			odds = royalFlush (hand,kepthand,draw);
			showProb(odds,0);
		}
	}
	public void showProb(double prob, int rowId){
		//takes probability of a hand and rowId of the display row and updates the result
		TableLayout tl= (TableLayout) findViewById(R.id.hand);
		TableRow row= (TableRow)tl.findViewById(rowId);
		TextView tv= (TextView) row.findViewWithTag(6);
		prob=prob*100;
		if (prob < 0.001){//double converts to scientific notation  after 10^-3
			if(prob < 0.00051){
				prob=0;
			}
			else{
				prob=0.001;
			}
		}
		String result=Double.toString(prob);
		if (result.length()<4){
			tv.setText(result+"0%");
		}
		else{
			tv.setText(result.substring(0, 4)+"%");

		}
	}
	public void about(View view){
    	Intent jack = new Intent(this, MainActivity.class);
    	startActivity(jack);
	}
}