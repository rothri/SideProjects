package com.jacks.pokerodds;

import android.view.View;

public interface OnSubmitListener {
	 public void cardSelected(String s,int v);
}
